"""
Verifies the real outcome: report.json must exist, be valid JSON, contain the
required fields, and match values independently recomputed from access.log
(not just "the file exists").
"""
import json
import re
from collections import Counter
from pathlib import Path

REPORT_PATH = Path("/app/report.json")
LOG_PATH = Path("/app/access.log")

REQUIRED_FIELDS = ("total_requests", "unique_ips", "top_path")


def _expected():
    """Independently recompute the expected report from the raw log."""
    paths, ips, total = Counter(), set(), 0
    with open(LOG_PATH) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            total += 1
            ips.add(line.split()[0])
            m = re.search(r'"(?:GET|POST|PUT|DELETE|HEAD|PATCH) (\S+) ', line)
            if m:
                paths[m.group(1)] += 1
    top_count = max(paths.values())
    top_candidates = {p for p, c in paths.items() if c == top_count}
    return {
        "total_requests": total,
        "unique_ips": len(ips),
        "top_candidates": top_candidates,
    }


def _load_report():
    assert REPORT_PATH.exists(), "no report.json found at /app/report.json"
    text = REPORT_PATH.read_text()
    try:
        data = json.loads(text)
    except json.JSONDecodeError as e:
        raise AssertionError(f"report.json is not valid JSON: {e}")
    assert isinstance(data, dict), "report.json must contain a JSON object"
    return data


def test_report_exists_and_is_valid_json_object():
    _load_report()


def test_report_has_required_fields():
    data = _load_report()
    missing = [k for k in REQUIRED_FIELDS if k not in data]
    assert not missing, f"report.json is missing required field(s): {missing}"


def test_total_requests_is_correct():
    data = _load_report()
    expected = _expected()
    assert data["total_requests"] == expected["total_requests"], (
        f"total_requests: expected {expected['total_requests']}, "
        f"got {data.get('total_requests')!r}"
    )


def test_unique_ips_is_correct():
    data = _load_report()
    expected = _expected()
    assert data["unique_ips"] == expected["unique_ips"], (
        f"unique_ips: expected {expected['unique_ips']}, "
        f"got {data.get('unique_ips')!r}"
    )


def test_top_path_is_correct():
    data = _load_report()
    expected = _expected()
    assert data["top_path"] in expected["top_candidates"], (
        f"top_path: expected one of {sorted(expected['top_candidates'])}, "
        f"got {data.get('top_path')!r}"
    )
