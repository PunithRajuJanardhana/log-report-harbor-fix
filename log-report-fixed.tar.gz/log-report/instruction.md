# Log report

There is an Apache-style access log at `/app/access.log` in the working
directory. Write a script (in any language available in the environment) that
parses it and produces a JSON summary report at `/app/report.json`.

## Required output

`/app/report.json` must be a single JSON object with exactly these fields:

1. `total_requests` (integer) — the total number of non-empty log lines.
2. `unique_ips` (integer) — the count of distinct client IP addresses (the
   first whitespace-separated token on each line).
3. `top_path` (string) — the request path (e.g. `/index.html`) that appears
   most often across all requests, extracted from the quoted request line
   (`"GET /index.html HTTP/1.1"` -> `/index.html`). Ties may be broken by
   picking any one of the tied paths with the maximum count.

## Success criteria

Your solution is correct if and only if:

1. `/app/report.json` exists and is valid JSON.
2. It contains the three fields above, with no missing keys.
3. `total_requests`, `unique_ips`, and `top_path` exactly match the values
   computed by parsing `/app/access.log` as described above.
